This is the Bambotoo modules directory.

Modules have to be in a subdirectory to be loaded.

A directory or module that starts with a _ is complettely igonred.
This is a convenient way to disable modules

